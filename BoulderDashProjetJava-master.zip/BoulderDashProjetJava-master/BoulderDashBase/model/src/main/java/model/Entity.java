package model;

import java.awt.Graphics2D;

public class Entity {

	protected int x;
	protected int y;
	
	public Entity(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
	

	public void update()
	{
		
	}
	
	public void draw(Graphics2D g2d)
	{
		
	}
}
